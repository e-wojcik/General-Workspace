﻿Set-ExecutionPolicy Unrestricted
$action = New-ScheduledTaskAction -Execute 'Powershell.exe'-Argument '-NoProfile -WindowStyle Hidden -command "& 
{
@echo off

REG DELETE "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Wpad" /f
REG DELETE  "HKLM\Software\policies\Microsoft\Windows NT\DNSClient" /f

REG ADD "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Wpad"
REG ADD "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Wpad" /v "WpadOverride" /t REG_DWORD /d "1" /f


REG ADD  "HKLM\Software\policies\Microsoft\Windows NT\DNSClient"
REG ADD  "HKLM\Software\policies\Microsoft\Windows NT\DNSClient" /v "EnableMulticast" /t REG_DWORD /d "0" /f
}"'

$trigger =  New-ScheduledTaskTrigger -Daily -At 12am

Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "Prevent Responder Attack" -Description "(WPAD & LLMNR)"
Set-ExecutionPolicy Restricted